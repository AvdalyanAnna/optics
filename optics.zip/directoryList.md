|-- undefined
    |-- .gitignore
    |-- config.js
    |-- gulpfile.js
    |-- package-lock.json
    |-- package.json
    |-- readme.md
    |-- tailwind.config.js
    |-- _config.yml
    |-- build
    |   |-- index.html
    |   |-- css
    |   |   |-- style.css
    |   |-- img
    |   |   |-- cover.jpg
    |   |-- js
    |       |-- scripts.js
    |-- dist
    |   |-- index.html
    |   |-- css
    |   |   |-- style.css
    |   |-- img
    |   |   |-- cover.jpg
    |   |-- js
    |       |-- scripts.js
    |-- src
        |-- index.html
        |-- css
        |   |-- a.tailwind.scss
        |   |-- main.scss
        |-- img
        |   |-- cover.jpg
        |-- js
            |-- main.js
            |-- external
            |   |-- external.js
            |-- libs
                |-- library.js
